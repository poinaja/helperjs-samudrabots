# -*- coding: utf-8 -*-
# -*- Samudra____Bots -*-
# -*- version: Bots__Helper v.03 2020 -*-
# -*- creator: Samudra -*-
from bangsamudra import *
from akad.ttypes import Message
from liff.ttypes import LiffChatContext, LiffContext, LiffSquareChatContext, LiffNoneContext, LiffViewRequest
from akad.ttypes import ContentType as Type
from akad.ttypes import TalkException
from samudrabots.thrift.protocol import TCompactProtocol
from samudrabots.thrift.transport import THttpClient
from samudrabots.ttypes import LoginRequest
from datetime import datetime, timedelta
from time import sleep
from bs4 import BeautifulSoup
from humanfriendly import format_timespan, format_size, format_number, format_length
from gtts import gTTS
from threading import Thread
from io import StringIO
from multiprocessing import Pool
from googletrans import Translator
from urllib.parse import urlencode
from wikiapi import WikiApi
from tmp.MySplit import *
from zalgo import zalgoname
from random import randint
from shutil import copyfile
from youtube_dl import YoutubeDL
import LineService
import subprocess, youtube_dl, humanize, traceback
import subprocess as cmd
import time, random, sys, json, null, codecs, html5lib ,shutil ,threading, glob, re, base64, string, os, requests, six, ast, pytz, wikipedia, urllib, urllib.parse, atexit, asyncio, traceback
_session = requests.session()
try:
    import urllib.request as urllib2
except ImportError:
    import urllib2
#=====================================================================
#=====================================================================
appF = "IOS\t9.18.1.2019.1028.1835\tiOS\t12.4.1"
samudra = LINE("email","sandi")
#=======================================================
waitOpen = codecs.open("wait.json","r","utf-8")
settingsOpen = codecs.open("temp.json","r","utf-8")
tokenOpen = codecs.open("toket.json","r","utf-8")
premiumOpen = codecs.open("user.json","r","utf-8")
#=====================================================================
#=====================================================================
khieProfile = samudra.getProfile()
khieSettings = samudra.getSettings()
khiePoll = OEPoll(samudra)
khieMID = samudra.getProfile().mid
#=====================================================================
#=====================================================================
loop = asyncio.get_event_loop()
admin =["mid"]
myAdmin = ["mid"]
botStart = time.time()
msg_dict = {}
temp_flood = {}
groupName = {}
groupImage = {}
kuciyose = {}
protectname = []
wbanlist = []
protectinvite = []
protectkick = []
protectjoin = []
protectqr = []
protectantijs = []
wait = json.load(waitOpen)
settings = json.load(settingsOpen)
token = json.load(tokenOpen)
premium = json.load(premiumOpen)
responsename = samudra.getProfile().displayName
listToken = ['desktopmac','desktopwin','iosipad','chromeos','win10']

kimak= {
    "Addaudio": False,
    "Audio": {},
    "Audios": {
     },
}

hoho = {
    "savefile": False,
    "namefile": "",
}

itil = {
    "blacklist": {},
}

peler = {
    "receivercount": 0,
    "sendcount": 0
}

chatbot = {
    "admin": [],
    "botMute": [],
    "botOff": [],
}

read = {
    "readMember": {},
    "readPoint": {}
}
#=====================================================================
settings["myProfile"]["displayName"] = khieProfile.displayName
settings["myProfile"]["statusMessage"] = khieProfile.statusMessage
settings["myProfile"]["pictureStatus"] = khieProfile.pictureStatus
cont = samudra.getContact(khieMID)
settings["myProfile"]["videoProfile"] = cont.videoProfile
coverId = samudra.getProfileDetail()["result"]["objectId"]
settings["myProfile"]["coverId"] = coverId
#=====================================================================
helpMessage1 ="""     ⇱ sᴀмuᴅʀᴀ____ʙoтs ⇲
╔═══════════════════╗
╠👻● help admin
╠👻● kiss me
╠👻● cmd
╠👻● leave
╠👻● list user
╠👻● name [text]
╠👻● status [text]
╠👻● ping
╠👻● join on
╠👻● join off
╠👻● change cover
╠👻● mention
╠👻● bye
╠👻● skill @
╠👻● debug
╠👻● speed
╠👻● glist
╠👻● bcast [text]
╠👻● openqr [number]
╠👻● addme [name]
╠👻● adduser @
╠👻● deluser @
╠👻● logout @
╠👻● myscreen
╠👻● myfilevps
╠👻● hapusfile [txt]
╠👻● unzip [txt]
╠👻● run bots
╠👻● logout bots
╠👻● run purge
╠👻● logout purge
╚═══════════════════╝"""
helpMessage2 ="""     ⇱ sᴀмuᴅʀᴀ____ʙoтs ⇲
╔═══════════════════╗
╠⇱ usᴇʀ____sᴀмuᴅʀᴀ ⇲
╠👻● help
╠👻● login template
╠👻● logout template
╠👻● restart template
╠👻● login sbbiasa
╠👻● logout sbbiasa
╠👻● restart sbbiasa
╠👻● login js
╠👻● logout js
╠👻● restart js
╠👻● help login
╠👻● get token
╠👻● ping
╚═══════════════════╝"""
#=====================================================================
with open("temp.json", "r", encoding="utf_8_sig") as f:
    anu = json.loads(f.read())
    anu.update(settings)
    settings = anu
with open("wait.json", "r", encoding="utf_8_sig") as f:
    itu = json.loads(f.read())
    itu.update(wait)
    wait = itu

def debug():
    get_profile_time_start = time.time()
    get_profile = samudra.getProfile()
    get_profile_time = time.time() - get_profile_time_start
    get_group_time_start = time.time()
    get_group = samudra.getGroupIdsJoined()
    get_group_time = time.time() - get_group_time_start
    get_contact_time_start = time.time()
    get_contact = samudra.getContact(get_profile.mid)
    get_contact_time = time.time() - get_contact_time_start
    elapsed_time = time.time() - get_profile_time_start
    return " 「 Debug 」\n - Send Message\n   %.5f\n - Get Profile\n   %.5f\n - Get Contact\n   %.5f\n - Get Group\n   %.5f" % (elapsed_time,get_profile_time,get_contact_time,get_group_time)
#=====================================================================
def headers2():
    Headers = {
    'User-Agent': "Line/9.21.2",
    'X-Line-Application': "IOSIPAD\t9.22.2\tIPAD\t12.2",
    "x-lal": "ja-US_US",
    }
    return Headers
#=====================================================================
def restartBot():
    print ("[ INFO ] BOT RESETTED")
    backupData()
    python = sys.executable
    os.execl(python, python, *sys.argv)
#=====================================================================
def getToken(to, header="ios_ipad"):
    auth = "tokennya"
    result = json.loads(requests.get("https://api.boteater.us/line_qr_v2?header="+header+"&auth="+auth).text)
    samudra.sendMessage(to, "Login IP: {} \nQR Link: {}".format(result["result"]["login_ip"],result["result"]["qr_link"]))
    result = json.loads(requests.get(result["result"]["callback"]+"&auth="+auth).text)
    if result["status"] != 200:
        raise Exception("Timeout!!!")
    samudra.sendMessage(to, "Pincode: "+result["result"]["pin_code"])
    result = json.loads(requests.get(result["result"]["callback"]+"&auth="+auth).text)
    if result["status"] != 200:
        raise Exception("Timeout!!!")
    return result["result"]["token"]
#=====================================================================
def sendMention(to, mid, firstmessage='', lastmessage=''):
    try:
        arrData = ""
        text = "%s " %(str(firstmessage))
        arr = []
        mention = "@x "
        slen = str(len(text))
        elen = str(len(text) + len(mention) - 1)
        arrData = {'S':slen, 'E':elen, 'M':mid}
        arr.append(arrData)
        text += mention + str(lastmessage)
        try:
            samudra.sendMessage(to, text, {'MSG_SENDER_NAME': samudra.getContact(mid).displayName,'MSG_SENDER_ICON': "http://dl.profile.line-cdn.net/" + samudra.getContact(mid).pictureStatus,'MENTION': str('{"MENTIONEES":' + json.dumps(arr) + '}')}, 0)
        except Exception as e:
            samudra.sendMessage(to, text, {'MSG_SENDER_NAME': samudra.getContact("ue5e4c36dae9280211ff0eb66cd39b755").displayName,'MSG_SENDER_ICON': 'http://dl.profile.line-cdn.net/' + samudra.getContact("ue5e4c36dae9280211ff0eb66cd39b755").pictureStatus,'MENTION': str('{"MENTIONEES":' + json.dumps(arr) + '}')}, 0)
    except Exception as error:
        print(error)
def mentions(to, text="", mids=[]):
    arrData = ""
    arr = []
    mention = "@KhieGans  "
    if mids == []:
        raise Exception("Invalid mids")
    if "@!" in text:
        if text.count("@!") != len(mids):
            raise Exception("Invalid mids")
        texts = text.split("@!")
        textx = ""
        for mid in mids:
            textx += str(texts[mids.index(mid)])
            slen = len(textx)
            elen = len(textx) + 15
            arrData = {'S':str(slen), 'E':str(elen - 4), 'M':mid}
            arr.append(arrData)
            textx += mention
        textx += str(texts[len(mids)])
    else:
        textx = ""
        slen = len(textx)
        elen = len(textx) + 15
        arrData = {'S':str(slen), 'E':str(elen - 4), 'M':mids[0]}
        arr.append(arrData)
        textx += mention + str(text)
    samudra.sendMessage(to, textx, {'AGENT_NAME':'LINE OFFICIAL', 'AGENT_LINK': 'line://ti/p/~{}'.format(samudra.getProfile().userid), 'AGENT_ICON': "http://dl.profile.line-cdn.net/" + samudra.getContact("ue5e4c36dae9280211ff0eb66cd39b755").picturePath, 'MENTION': str('{"MENTIONEES":' + json.dumps(arr) + '}')}, 0)

def changeVideoAndPictureProfile(pict, vids):
    try:
        files = {'file': open(vids, 'rb')}
        obs_params = samudra.genOBSParams({'oid': khieMID, 'ver': '2.0', 'type': 'video', 'cat': 'vp.mp4'})
        data = {'params': obs_params}
        r_vp = samudra.server.postContent('{}/talk/vp/upload.nhn'.format(str(samudra.server.LINE_OBS_DOMAIN)), data=data, files=files)
        if r_vp.status_code != 201:
            return "Failed update profile"
        samudra.updateProfilePicture(pict, 'vp')
        return "Success update profile"
    except Exception as e:
        raise Exception("Error change video and picture profile {}".format(str(e)))
        os.remove("KhieWasHere.mp4")

def sendCarousel(to,col):
    col = json.dumps(col)
    xyz = LiffChatContext(to)
    xyzz = LiffContext(chat=xyz)
    view = LiffViewRequest('1602687308-GXq4Vvk9', xyzz)
    token = client.issueLiffView(view)
    url = 'https://api.line.me/message/v3/share'
    headers = {
        'Content-Type': 'application/json',
        'Authorization': 'Bearer %s' % token.accessToken
    }
    return requests.post(url, data=col, headers=headers)
#=====================================================================
def speedtest(secs):
    mins, secs = divmod(secs,60)
    hours, mins = divmod(mins,60)
    days, hours = divmod(hours,24)
    weaks, days = divmod(days,7)
    if days == 0:
        return '%02d' % (secs)
    elif days > 0 and weaks == 0:
        return '%02d' %(secs)
    elif days > 0 and weaks > 0:
        return '%02d' %(secs)

def change(url):
	import base64
	return base64.b64encode(url.encode()).decode()

def tagdia(to, text="",ps='', mids=[]):
        arrData = ""
        arr = []
        mention = "@MentionOrang "
        if mids == []:
            raise Exception("Invalid mids")
        if "@!" in text:
            if text.count("@!") != len(mids):
                raise Exception("Invalid mids")
            texts = text.split("@!")
            textx = ''
            h = ''
            for mid in range(len(mids)):
                h+= str(texts[mid].encode('unicode-escape'))
                textx += str(texts[mid])
                if h != textx:slen = len(textx)+h.count('U0');elen = len(textx)+h.count('U0') + 13
                else:slen = len(textx);elen = len(textx) + 13
                arrData = {'S':str(slen), 'E':str(elen), 'M':mids[mid]}
                arr.append(arrData)
                textx += mention
            textx += str(texts[len(mids)])
        else:
            textx = ''
            slen = len(textx)
            elen = len(textx) + 18
            arrData = {'S':str(slen), 'E':str(elen - 4), 'M':mids[0]}
            arr.append(arrData)
            textx += mention + str(text)
        samudra.sendMessage(to, textx, {'MSG_SENDER_NAME': samudra.getContact(ps).displayName,'MSG_SENDER_ICON': "http://dl.profile.line-cdn.net/" + samudra.getContact(ps).pictureStatus,'MENTION': str('{"MENTIONEES":' + json.dumps(arr) + '}')}, 0)
#=====================================================================
def logError(text):
    samudra.log("ERROR 404 !\n" + str(text))
    tz = pytz.timezone("Asia/Jakarta")
    timeNow = datetime.now(tz=tz)
    timeHours = datetime.strftime(timeNow,"(%H:%M)")
    day = ["Sunday", "Monday", "Tuesday", "Wednesday", "Thursday","Friday", "Saturday"]
    hari = ["Minggu", "Senin", "Selasa", "Rabu", "Kamis", "Jumat", "Sabtu"]
    bulan = ["Januari", "Februari", "Maret", "April", "Mei", "Juni", "Juli", "Agustus", "September", "Oktober", "November", "Desember"]
    inihari = datetime.now(tz=tz)
    hr = inihari.strftime('%A')
    bln = inihari.strftime('%m')
    for i in range(len(day)):
        if hr == day[i]: hasil = hari[i]
    for k in range(0, len(bulan)):
        if bln == str(k): bln = bulan[k-1]
    time = hasil + ", " + inihari.strftime('%d') + " - " + bln + " - " + inihari.strftime('%Y') + " | " + inihari.strftime('%H:%M:%S')
    with open("errorLog.txt","a") as error:
        error.write("\n[%s] %s" % (str(time), text))
#=====================================================================
def command(text):
    pesan = text.lower()
    if settings["setKey"] == True:
        if pesan.startswith(settings["keyCommand"]):
            cmd = pesan.replace(settings["keyCommand"],"")
        else:
            cmd = "Undefined command"
    else:
        cmd = text.lower()
    return cmd
#=====================================================================
def removeCmd(cmd, text):
	key = settings["keyCommand"]
	if settings["setKey"] == False: key = ''
	rmv = len(key + cmd) + 1
	return text[rmv:]
def backupData():
    try:
        backup = settings
        f = codecs.open('temp.json','w','utf-8')
        json.dump(backup, f, sort_keys=True, indent=4, ensure_ascii=False)
        backup = wait
        f = codecs.open('wait.json','w','utf-8')
        json.dump(backup, f, sort_keys=True, indent=4, ensure_ascii=False)
        backup = premium
        f = codecs.open('user.json','w','utf-8')
        json.dump(backup, f, sort_keys=True, indent=4, ensure_ascii=False)
        return True
    except Exception as error:
        logError(error)
        return False
#=====================================================================
async def khieBot(op):
    try:
        if settings["restartPoint"] != None:
            samudra.sendMessage(settings["restartPoint"], 'Activated♪')
            settings["restartPoint"] = None
        if op.type == 0:
            return

        if op.type in [22,24]:
            samudra.leaveRoom(op.param1)
#=====================================================================
        if op.type == 13:
            if khieMID in op.param3:
                if settings["autoJoin"] == True:
                    if op.param2 not in admin:samudra.acceptGroupInvitation(op.param1)
                    else:samudra.acceptGroupInvitation(op.param1)

        if op.type in [25, 26]:
            if op.type == 25: print ("[ 25 ] SEND MESSAGE")
            else: print ("[ 26 ] RECEIVE MESSAGE")
            msg = op.message
            text = msg.text
            msg_id = msg.id
            receiver = msg.to
            sender = msg._from
            s = samudra.getProfile().mid
            setKey = settings["keyCommand"].title()
            if settings["setKey"] == False:
               setKey = ''
            if msg.toType == 0 or msg.toType == 1 or msg.toType == 2:
                if msg.toType == 0:
                    if sender != samudra.profile.mid:
                        to = sender
                    else:
                        to = receiver
                elif msg.toType == 1:
                    to = receiver
                elif msg.toType == 2:
                    to = receiver
                if msg.contentType == 0:
                    if text is None:
                        return
                    else:
                        cmd = command(text)
                        if sender != s:
                	        peler["receivercount"] += 1
                        if sender == s:
                	        peler["sendcount"] += 1
#=====================================================================
        if op.type == 26:
            print ("[ 26 ] RECEIVE MESSAGE")
            msg = op.message
            text = str(msg.text)
            msg_id = msg.id
            receiver = msg.to
            sender = msg._from
            to = msg.to
            cmd = command(text)
            isValid = True
            setKey = settings["keyCommand"].title()
            if settings["setKey"] == False: setKey = ''
            if isValid != False:
                if msg.toType == 0 and sender != khieMID: to = sender
                else: to = receiver
                if msg.contentType == 6:
                    try:
                        contact = samudra.getContact(sender)
                        if msg.toType == 2:
                            anu = samudra.getGroup(to)
                            if msg.contentMetadata['GC_EVT_TYPE'] == 'S' and msg.contentMetadata['GC_MEDIA_TYPE'] == 'LIVE':
                                anu = msg.contentMetadata={'GC_EVT_TYPE': 'S', 'GC_CHAT_MID': to, 'RESULT': 'INFO', 'SKIP_BADGE_COUNT': 'false', 'GC_IGNORE_ON_FAILBACK': 'false', 'TYPE': 'G', 'DURATION': '0', 'GC_MEDIA_TYPE': 'VIDEO', 'VERSION': 'X', 'CAUSE': '16'}
                    except Exception as e:
                        samudra.sendMessage(to, str(e))
        if op.type == 26:
            print ("[ 26 ] RECEIVE MESSAGE")
            msg = op.message
            text = str(msg.text)
            msg_id = msg.id
            receiver = msg.to
            sender = msg._from
            to = msg.to
            cmd = command(text)
            isValid = True
            setKey = settings["keyCommand"].title()
            if settings["setKey"] == False: setKey = ''
            if isValid != False:
                if msg.toType == 0 and sender != khieMID: to = sender
                else: to = receiver
                if msg.contentType == 14:
                    if hoho["savefile"] == True:
                        try:
                             namafile = hoho["namafile"]
                             samudra.downloadObjectMsg(msg_id,saveAs=namafile)
                             hoho["savefile"] = False
                             samudra.sendMessage(to, "Successful, the file has been uploaded")
                        except Exception as e:
                         	samudra.sendMessage(to, str(e))
                if msg.contentType == 1:
                    if settings["changeCoverProfile"] == True:
                        path = samudra.downloadObjectMsg(msg_id)
                        settings["changeCoverProfile"] = False
                        samudra.updateProfileCover(path)
                        samudra.sendMessage(to,"Cover Image Updated.")
                if msg.contentType in [0,1,2,3,4,5,6,7,8,9,10,11,12,13,14,15,16,17,18,19,20,21]:
                    if msg.toType == 0:
                        if settings["autoRead"] == True:
                            samudra.sendChatChecked(to, msg_id)
                    if msg.toType == 2:
                        if settings["autoRead1"] == True:
                            samudra.sendChatChecked(to, msg_id)
                if msg.contentType == 0:
                    if "/ti/g/" in text.lower():
                        if settings["autoJoin"] == True:
                            link_re = re.compile('(?:line\:\/|line\.me\/R)\/ti\/g\/([a-zA-Z0-9_-]+)?')
                            links = link_re.findall(text)
                            n_links = []
                            for l in links:
                                if l not in n_links:
                                   n_links.append(l)
                            for ticket_id in n_links:
                                group = samudra.findGroupByTicket(ticket_id)
                                if len(group.members) >= wait["Members"]:
                                    samudra.acceptGroupInvitationByTicket(group.id,ticket_id)
                                else:
                                    samudra.acceptGroupInvitationByTicket(group.id,ticket_id)
                                    samudra.leaveGroup(group.id)
#==========================================
                    elif cmd == "help admin":
                        if msg._from in myAdmin:
                            samudra.sendMessage(to, helpMessage1)
                    elif cmd == "help":
                        samudra.sendMessage(to, helpMessage2)
                    elif cmd == "change cover":
                        if msg._from in myAdmin:
                            settings["changeCoverProfile"] = True
                            samudra.sendMessage(to,"Send a Image to change cover.")
#==========================================
                    if cmd == "kiss me":
                        samudra.generateReplyMessage(msg.id)
                        samudra.sendReplyMessage(msg.id, to,"。。・゜゜・❤ "+samudra.getContact(sender).displayName+" ❤ \n(muahhhhづ￣ ³￣)づ")
#==========================================
                    elif cmd == "cmd":
                        if msg._from in myAdmin:
                            ret = "Help Message\n\n"
                            ret += "  • glist\n"
                            ret += "  • skill\n"
                            ret += "  • slain\n"
                            ret += "  • cvp\n"
                            ret += "  • debug\n"
                            ret += "  • speed\n"
                            ret += "  • bcast\n"
                            ret += "  • leave"
                            samudra.sendMessage(to, "{}".format(str(ret)))
#==========================================
                    elif cmd.startswith("leave "):
                        if msg._from in myAdmin:
                            number = removeCmd("leave", text)
                            groups = samudra.getGroupIdsJoined()
                            try:
                                group = groups[int(number)-1]
                                G = samudra.getGroup(group)
                                try:
                                    samudra.leaveGroup(G.id)
                                except:
                                    samudra.leaveGroup(G.id)
                                samudra.sendMessage(to, "「Leave 」\n\nGroup : " + G.name)
                            except Exception as error:
                                samudra.sendMessage(to, str(error))
#==========================================
                    if cmd == "chat maker":
                        samudra.sendMention(msg.to, 'Hallo @! if u want chat my creator\nType : Chatmaker [text]\nExample : Chatmaker hi samudra',' ', [msg._from])
                    elif cmd.startswith("chatmaker "):
                        sep = text.split(" ")
                        txt = text.replace(sep[0] + " ","")
                        contact = samudra.getContact(sender)
                        owner = "u237194db141cbd58c66c8dc519a31dec"
                        mat_ = "Sender: @!"
                        mat_ += "\nMessage: {}".format(txt)
                        mat = {
                            'MSG_SENDER_ICON': "http://dl.profile.line-cdn.net/" + contact.pictureStatus,
                            'MSG_SENDER_NAME':  contact.displayName,
                            'mid': sender,
                        }
                        mid = samudra.getContact(sender).displayName
                        mentions(owner, mat_, [sender])
                        samudra.sendMessage(owner, mid, contentMetadata=mat, contentType=13)
                        samudra.sendMention(to, "Hi @!\nYour message has been send ^_^","",[msg._from])
#==========================================
                    elif text.lower() == "list user" and msg._from not in myAdmin and to not in chatbot["botMute"]:
                        samudra.sendMention(msg.to, 'Type : List user selfbot\n\nHai @! Sorry you are not Owner',' ', [msg._from])
                    elif text.lower() == "restart sb" and msg._from not in premium["myService"]:
                        samudra.sendMention(msg.to, 'Type : Restart selfbot\n\nHai @! Sorry You are not listed In List Premium',' ', [msg._from])
                    elif text.lower() == "login sb" and msg._from not in premium["myService"]:
                        samudra.sendMention(msg.to, 'Type : Login selfbot\n\nHai @! Sorry You are not listed In List Premium',' ', [msg._from])
                    elif text.lower() == "help login" and msg._from not in premium["myService"]:
                        samudra.sendMention(msg.to, 'Type : Help login selfbot\n\nHai @! Sorry You are not listed In List Premium',' ', [msg._from])
                    elif text.lower() == "logout sb" and msg._from not in premium["myService"]:
                        samudra.sendMention(msg.to, 'Type : LogOut selfbot\n\nHai @! Sorry You are not listed In List Premium',' ', [msg._from])
#==========================================
                    elif cmd.startswith("name "):
                        if msg._from in myAdmin:
                            string = removeCmd("#name", text)
                            if len(string) <= 10000000000:
                                pname = samudra.getContact(sender).displayName
                                profile = samudra.getProfile()
                                profile.displayName = string
                                samudra.updateProfile(profile)
                                samudra.sendMessage(to, "「 Update Name 」\nStatus : Success\nFrom : "+str(pname)+"\nTo :"+str(string))
                    elif cmd.startswith("status "):
                        if msg._from in myAdmin:
                            string = removeCmd("#status", text)
                            if len(string) <= 10000000000:
                                pname = samudra.getContact(sender).statusMessage
                                profile = samudra.getProfile()
                                profile.statusMessage = string
                                samudra.updateProfile(profile)
                                samudra.sendMessage(to, "「 Update Status 」\nStatus : Success\nFrom : "+str(pname)+"\nTo :"+str(string))
#==========================================
                    elif cmd == "ping":
                        if msg._from in myAdmin:
                            samudra.sendMention(to, "PONG ! @!","",[msg._from])
#==========================================
                    elif cmd == "join on":
                        if msg._from in myAdmin:
                            if settings["autoJoin"] == True:
                                msgs=" 「 Join 」\nJoin already Enable♪"
                            else:
                                msgs=" 「 Join 」\nJoin set to Enable♪"
                                settings["autoJoin"] = True
                            samudra.sendMessage(to, msgs)
                    elif cmd == "join off":
                        if msg._from in myAdmin:
                            if settings["autoJoin"] == False:
                                msgs=" 「 Join 」\nJoin already DISABLED♪"
                            else:
                                msgs=" 「 Join 」\nJoin set to DISABLED♪"
                                settings["autoJoin"] = False
                            samudra.sendMessage(to, msgs)
#==========================================
                    elif cmd== 'bye':
                        if msg._from in myAdmin:
                            samudra.leaveGroup(to)
#==========================================
                    elif cmd.startswith("skill "):
                        if msg._from in myAdmin:
                           sep = text.split(" ")
                           midn = text.replace(sep[0] + " ","")
                           hmm = text.lower()
                           G = samudra.getGroup(msg.to)
                           members = [G.mid for G in G.members]
                           targets = []
                           for x in members:
                               contact = samudra.getContact(x)
                               msg = op.message
                               testt = contact.displayName.lower()
                                   #print(testt)
                               if midn in testt:targets.append(contact.mid)
                           if targets == []:return samudra.sendMessage(to,"not found name "+midn)
                           for target in targets:
                               samudra.kickoutFromGroup(msg.to,[target])
                    elif cmd.startswith("slain "):
                        if msg._from in myAdmin:
                           sep = text.split(" ")
                           midn = text.replace(sep[0] + " ","")
                           hmm = text.lower()
                           G = samudra.getGroup(msg.to)
                           members = [G.mid for G in G.members]
                           targets = []
                           for x in members:
                               contact = samudra.getContact(x)
                               msg = op.message
                               testt = contact.displayName.lower()
                                   #print(testt)
                               if midn in testt:targets.append(contact.mid)
                           if targets == []:return samudra.sendMessage(to,"not found name "+midn)
                           for target in targets:
                               samudra.kickoutFromGroup(msg.to,[target])
                               samudra.findAndAddContactsByMid(target)
                               samudra.inviteIntoGroup(msg.to, [target])
                               samudra.cancelGroupInvitation(msg.to, [target])
                               time.sleep(5)
                               samudra.inviteIntoGroup(msg.to, [target])
#==========================================
                    elif cmd.startswith("cvp"):
                        if msg._from in myAdmin:
                            link = removeCmd("helper:cvp", text)
                            contact = samudra.getContact(sender)
                            samudra.sendMessage(to, "Type: Profile\n • Detail: Change video url\n • Status: Download...")
                            print("Sedang Mendownload Data ~")
                            pic = "http://dl.profile.line-cdn.net/{}".format(contact.pictureStatus)
                            subprocess.getoutput('youtube-dl --format mp4 --output TeamAnuBot.mp4 {}'.format(link))
                            pict = samudra.downloadFileURL(pic)
                            vids = "TeamAnuBot.mp4"
                            time.sleep(2)
                            changeVideoAndPictureProfile(pict, vids)
                            samudra.sendMessage(to, "Type: Profile\n • Detail: Change video url\n • Status: Succes")
                            os.remove("TeamAnuBot.mp4")
#==========================================
                    elif cmd == "debug":
                       if msg._from in myAdmin:
                            samudra.sendMessage(to, debug())
                    elif cmd == "login qr":
                            samudra.sendMessage(to, getToken())
                    elif cmd == "speed":
                        start = time.time()
                        samudra.sendMessage("ue5e4c36dae9280211ff0eb66cd39b755", '</>')
                        elapsed_time = time.time() - start
                        samudra.sendMessage(to,"Time:\n%s"%str(round(elapsed_time,5)))
#==========================================
                    elif cmd == "glist":
                       if msg._from in myAdmin:
                            key = settings["keyCommand"].title()
                            if settings['setKey'] == False:key = ''
                            gid = samudra.getGroupIdsJoined()
                            sd = samudra.getGroups(gid)
                            ret = "「 Group List 」\n"
                            no = 0
                            total = len(gid)
                            cd = "\n\nTotal {} Groups\n".format(total)
                            for G in sd:
                                member = len(G.members)
                                no += 1
                                ret += "\n{}. {} {}".format(no, G.name[0:20], member)
                            ret += cd
                            k = len(ret)//10000
                            for aa in range(k+1):
                                samudra.generateReplyMessage(msg.id)
                                samudra.sendReplyMessage(msg.id, to,'{}'.format(ret[aa*10000 : (aa+1)*10000]))
                    elif cmd.startswith("bcast"):
                      if msg._from in myAdmin:
                        tod = text.split(" ")
                        hey = text.replace(tod[0] + " ", "")
                        text = "{}".format(hey)
                        groups = samudra.getGroupIdsJoined()
                        friends = samudra.getAllContactIds()
                        for gr in groups:
                            samudra.sendMessage(to, "Succes Group cast to {} group ".format(str(len(groups))))
                    elif cmd.startswith("openqr "):
                      if msg._from in myAdmin:
                            number = removeCmd("openqr", text)
                            groups = samudra.getGroupIdsJoined()
                            try:
                                group = groups[int(number)-1]
                                G = samudra.getGroup(group)
                                try:
                                    G.preventedJoinByTicket = False
                                    samudra.updateGroup(G)
                                    gurl = "https://line.me/R/ti/g/{}".format(str(samudra.reissueGroupTicket(G.id)))
                                except:
                                    G.preventedJoinByTicket = False
                                    samudra.updateGroup(G)
                                    gurl = "https://line.me/R/ti/g/{}".format(str(samudra.reissueGroupTicket(G.id)))
                                samudra.sendMessage(to, "「 Open Qr 」\n\nGroup : " + G.name + "\nLink: " + gurl)
                            except Exception as error:
                                samudra.sendMessage(to, str(error))
#==========================================
                    elif text.lower() == "get token":
                        try:
                            header = "ios_ipad"
                            auth = "ruOsfDvqpJ3i"
                            result = json.loads(requests.get("https://api.boteater.us/line_qr_v2?header="+header+"&auth="+auth).text)
                            samudra.sendMessage(to, "Login IP: {} \nQR Link: {}".format(result["result"]["login_ip"],result["result"]["qr_link"]))
                            result = json.loads(requests.get(result["result"]["callback"]+"&auth="+auth).text)
                            if result["status"] != 200:
                                raise Exception("Timeout!!!")
                            samudra.sendMessage(to, "Pincode: "+result["result"]["pin_code"])
                            result = json.loads(requests.get(result["result"]["callback"]+"&auth="+auth).text)
                            if result["status"] != 200:
                                raise Exception("Timeout!!!")
                            zzz = result["result"]["token"]
                            samudra.sendMessage(to, zzz)
                        except:pass
#==========================================
                    elif text.lower() == "login js" and msg._from not in premium['listLogin'] and to not in chatbot["botMute"]:
                        if msg._from in premium["myService"]:
                            user = premium["myService"][msg._from]
                            try:
                                header = "ios_ipad"
                                auth = "x1ecaWcTbGHO"
                                result = json.loads(requests.get("https://api.boteater.us/line_qr_v2?header="+header+"&auth="+auth).text)
                                samudra.sendMessage(to, "Login IP: {} \nQR Link: {}".format(result["result"]["login_ip"],result["result"]["qr_link"]))
                                result = json.loads(requests.get(result["result"]["callback"]+"&auth="+auth).text)
                                if result["status"] != 200:
                                    raise Exception("Timeout!!!")
                                samudra.sendMessage(to, "Pincode: "+result["result"]["pin_code"])
                                result = json.loads(requests.get(result["result"]["callback"]+"&auth="+auth).text)
                                if result["status"] != 200:
                                    raise Exception("Timeout!!!")
                                zzz = result["result"]["token"]
                                if msg._from not in premium['listLogin']:
                                    premium['listLogin'][msg._from] =  '%s' % user
                                    isi = "{}".format(zzz)
                                    os.system('cp -r samudrajs {}'.format(user))
                                    os.system('cd {} && echo -n "{}" > token1.txt'.format(user, isi))
                                    os.system('screen -dmS {}'.format(user))
                                    os.system('screen -r {} -X stuff "cd {} && python3 samjs.py \n"'.format(user, user))
                                    samudra.sendMessage(to, "Login Succes")
                                else:
                                    samudra.sendMention(msg.to, '「 Request Login 」\n@!\nLink QR Expired -_-',' ', [msg._from])
                            except:
                                samudra.sendMention(msg.to, '「  ERROR 」\n@!\nPlease Nonactive Filter Chat Or Letter Sealing -_-',' ', [msg._from])

                    elif text.lower() == "login js" and msg._from in premium['listLogin'] and to not in chatbot["botMute"]:
                        if msg._from in premium["myService"]:
                            samudra.sendMention(msg.to, '「 Login SelfBot 」\nHello @!Sorry Please Logout First Log In With Type  < Logout js >\nBecause You Are Still Login',' ', [msg._from])

                    elif text.lower() == "logout js" and msg._from in premium['listLogin'] and to not in chatbot["botMute"]:
                        if msg._from in premium["myService"]:
                            del premium['listLogin'][msg._from]
                            user = premium["myService"][msg._from]
                            os.system("screen -S {} -X quit".format(str(user)))
                            os.system('rm -rf {}'.format(str(user)))
                            time.sleep(2)
                            samudra.sendMention(msg.to, '「  Logout js  」\n> @! LogOut From Selfbot',' ', [msg._from])

                    elif text.lower() == "logout js" and msg._from not in premium['listLogin'] and to not in chatbot["botMute"]:
                        if msg._from in premium["myService"]:
                            samudra.sendMention(msg.to, '「  Logout kikil  」\nHai @!Sorry Please You Login First By Type < Login js > Or Type < Help Login >',' ', [msg._from])

                    elif text.lower() == "restart js" and to not in chatbot["botMute"]:
                        if msg._from in premium["myService"]:
                            user = premium["myService"][msg._from]
                            os.system("screen -S {} -X quit".format(str(user)))
                            os.system('screen -dmS {}'.format(user))
                            os.system('screen -r {} -X stuff "cd {} && python3 samjs.py \n"'.format(user, user))
                            time.sleep(3)
                            samudra.sendMention(msg.to, '「  Restart js  」\n> @! Succes Restart selfbot',' ', [msg._from])
#==========================================
                    elif text.lower() == "login sbbiasa" and msg._from not in premium['listLogin'] and to not in chatbot["botMute"]:
                        if msg._from in premium["myService"]:
                            user = premium["myService"][msg._from]
                            try:
                                header = "ios_ipad"
                                auth = "x1ecaWcTbGHO"
                                result = json.loads(requests.get("https://api.boteater.us/line_qr_v2?header="+header+"&auth="+auth).text)
                                samudra.sendMessage(to, "Login IP: {} \nQR Link: {}".format(result["result"]["login_ip"],result["result"]["qr_link"]))
                                result = json.loads(requests.get(result["result"]["callback"]+"&auth="+auth).text)
                                if result["status"] != 200:
                                    raise Exception("Timeout!!!")
                                samudra.sendMessage(to, "Pincode: "+result["result"]["pin_code"])
                                result = json.loads(requests.get(result["result"]["callback"]+"&auth="+auth).text)
                                if result["status"] != 200:
                                    raise Exception("Timeout!!!")
                                zzz = result["result"]["token"]
                                if msg._from not in premium['listLogin']:
                                    premium['listLogin'][msg._from] =  '%s' % user
                                    isi = "{}".format(zzz)
                                    os.system('cp -r biasa {}'.format(user))
                                    os.system('cd {} && echo -n "{}" > token1.txt'.format(user, isi))
                                    os.system('screen -dmS {}'.format(user))
                                    os.system('screen -r {} -X stuff "cd {} && python3 cok.py \n"'.format(user, user))
                                    samudra.sendMessage(to, "Login Succes")
                                else:
                                    samudra.sendMention(msg.to, '「 Request Login 」\n@!\nLink QR Expired -_-',' ', [msg._from])
                            except:
                                samudra.sendMention(msg.to, '「  ERROR 」\n@!\nPlease Nonactive Filter Chat Or Letter Sealing -_-',' ', [msg._from])

                    elif text.lower() == "login sbbiasa" and msg._from in premium['listLogin'] and to not in chatbot["botMute"]:
                        if msg._from in premium["myService"]:
                            samudra.sendMention(msg.to, '「 Login SelfBot 」\nHello @!Sorry Please Logout First Log In With Type  < Logout kikil >\nBecause You Are Still Login',' ', [msg._from])

                    elif text.lower() == "logout sbbiasa" and msg._from in premium['listLogin'] and to not in chatbot["botMute"]:
                        if msg._from in premium["myService"]:
                            del premium['listLogin'][msg._from]
                            user = premium["myService"][msg._from]
                            os.system("screen -S {} -X quit".format(str(user)))
                            os.system('rm -rf {}'.format(str(user)))
                            time.sleep(2)
                            samudra.sendMention(msg.to, '「  Logout kikil  」\n> @! LogOut From Selfbot',' ', [msg._from])

                    elif text.lower() == "logout sbbiasa" and msg._from not in premium['listLogin'] and to not in chatbot["botMute"]:
                        if msg._from in premium["myService"]:
                            samudra.sendMention(msg.to, '「  Logout kikil  」\nHai @!Sorry Please You Login First By Type < Login kikil > Or Type < Help Login >',' ', [msg._from])

                    elif text.lower() == "restart sbbiasa" and to not in chatbot["botMute"]:
                        if msg._from in premium["myService"]:
                            user = premium["myService"][msg._from]
                            os.system("screen -S {} -X quit".format(str(user)))
                            os.system('screen -dmS {}'.format(user))
                            os.system('screen -r {} -X stuff "cd {} && python3 cok.py \n"'.format(user, user))
                            time.sleep(3)
                            samudra.sendMention(msg.to, '「  Restart kikil  」\n> @! Succes Restart selfbot',' ', [msg._from])
#==========================================
                    elif text.lower() == "login template" and msg._from not in premium['listLogin'] and to not in chatbot["botMute"]:
                        if msg._from in premium["myService"]:
                            user = premium["myService"][msg._from]
                            try:
                                header = "ios_ipad"
                                auth = "x1ecaWcTbGHO"
                                result = json.loads(requests.get("https://api.boteater.us/line_qr_v2?header="+header+"&auth="+auth).text)
                                samudra.sendMessage(to, "Login IP: {} \nQR Link: {}".format(result["result"]["login_ip"],result["result"]["qr_link"]))
                                result = json.loads(requests.get(result["result"]["callback"]+"&auth="+auth).text)
                                if result["status"] != 200:
                                    raise Exception("Timeout!!!")
                                samudra.sendMessage(to, "Pincode: "+result["result"]["pin_code"])
                                result = json.loads(requests.get(result["result"]["callback"]+"&auth="+auth).text)
                                if result["status"] != 200:
                                    raise Exception("Timeout!!!")
                                zzz = result["result"]["token"]
                                if msg._from not in premium['listLogin']:
                                    premium['listLogin'][msg._from] =  '%s' % user
                                    isi = "{}".format(zzz)
                                    os.system('cp -r samtemp {}'.format(user))
                                    os.system('cd {} && echo -n "{}" > token1.txt'.format(user, isi))
                                    os.system('screen -dmS {}'.format(user))
                                    os.system('screen -r {} -X stuff "cd {} && python3 sb.py \n"'.format(user, user))
                                    samudra.sendMention(msg.to, '「 Login Succes 」\n> @!\n> User name : {}\n> Click link liff for access temp :\nline://app/1602687308-GXq4Vvk9?type=profile'.format(user),' ', [msg._from])
                                else:
                                    samudra.sendMention(msg.to, '「 Request Login 」\n@!\nLink QR Expired -_-',' ', [msg._from])
                            except:
                                samudra.sendMention(msg.to, '「  ERROR 」\n@!\nPlease Nonactive Filter Chat Or Letter Sealing -_-',' ', [msg._from])

                    elif text.lower() == "login template" and msg._from in premium['listLogin'] and to not in chatbot["botMute"]:
                        if msg._from in premium["myService"]:
                            samudra.sendMention(msg.to, '「 Login template 」\nHello @!Sorry Please Logout First Log In With Type  < Logout template >\nBecause You Are Still Login',' ', [msg._from])

                    elif text.lower() == "logout template" and msg._from in premium['listLogin'] and to not in chatbot["botMute"]:
                        if msg._from in premium["myService"]:
                            del premium['listLogin'][msg._from]
                            user = premium["myService"][msg._from]
                            os.system("screen -S {} -X quit".format(str(user)))
                            os.system('rm -rf {}'.format(str(user)))
                            time.sleep(2)
                            samudra.sendMention(msg.to, '「  Logout template  」\n> @! LogOut From Selfbot',' ', [msg._from])

                    elif text.lower() == "logout template" and msg._from not in premium['listLogin'] and to not in chatbot["botMute"]:
                        if msg._from in premium["myService"]:
                            samudra.sendMention(msg.to, '「  Logout template  」\nHai @!Sorry Please You Login First By Type < Login template > Or Type < Help Login >',' ', [msg._from])

                    elif text.lower() == "restart template" and to not in chatbot["botMute"]:
                        if msg._from in premium["myService"]:
                            user = premium["myService"][msg._from]
                            os.system("screen -S {} -X quit".format(str(user)))
                            os.system('screen -dmS {}'.format(user))
                            os.system('screen -r {} -X stuff "cd {} && python3 sb.py \n"'.format(user, user))
                            time.sleep(3)
                            samudra.sendMention(msg.to, '「  Restart template  」\n> @! Succes Restart selfbot',' ', [msg._from])
#==========================================
                    elif text.lower() == "login bypass" and msg._from not in premium['listLogin'] and to not in chatbot["botMute"]:
                        if msg._from in premium["myService"]:
                            user = premium["myService"][msg._from]
                            try:
                                header = "ios_ipad"
                                auth = "x1ecaWcTbGHO"
                                result = json.loads(requests.get("https://api.boteater.us/line_qr_v2?header="+header+"&auth="+auth).text)
                                samudra.sendMessage(to, "Login IP: {} \nQR Link: {}".format(result["result"]["login_ip"],result["result"]["qr_link"]))
                                result = json.loads(requests.get(result["result"]["callback"]+"&auth="+auth).text)
                                if result["status"] != 200:
                                    raise Exception("Timeout!!!")
                                samudra.sendMessage(to, "Pincode: "+result["result"]["pin_code"])
                                result = json.loads(requests.get(result["result"]["callback"]+"&auth="+auth).text)
                                if result["status"] != 200:
                                    raise Exception("Timeout!!!")
                                zzz = result["result"]["token"]
                                if msg._from not in premium['listLogin']:
                                    premium['listLogin'][msg._from] =  '%s' % user
                                    isi = "{}".format(zzz)
                                    os.system('cp -r byass {}'.format(user))
                                    os.system('cd {} && echo -n "{}" > token1.txt'.format(user, isi))
                                    os.system('screen -dmS {}'.format(user))
                                    os.system('screen -r {} -X stuff "cd {} && python3 bypass.py \n"'.format(user, user))
                                    samudra.sendMention(msg.to, '「 Login Succes 」\n> @!\n> User name : {}\n> Click link liff for access temp :\nline://app/1602687308-GXq4Vvk9?type=profile'.format(user),' ', [msg._from])
                                else:
                                    samudra.sendMention(msg.to, '「 Request Login 」\n@!\nLink QR Expired -_-',' ', [msg._from])
                            except:
                                samudra.sendMention(msg.to, '「  ERROR 」\n@!\nPlease Nonactive Filter Chat Or Letter Sealing -_-',' ', [msg._from])

                    elif text.lower() == "login bypass" and msg._from in premium['listLogin'] and to not in chatbot["botMute"]:
                        if msg._from in premium["myService"]:
                            samudra.sendMention(msg.to, '「 Login bypass 」\nHello @!Sorry Please Logout First Log In With Type  < Logout template >\nBecause You Are Still Login',' ', [msg._from])

                    elif text.lower() == "logout bypass" and msg._from in premium['listLogin'] and to not in chatbot["botMute"]:
                        if msg._from in premium["myService"]:
                            del premium['listLogin'][msg._from]
                            user = premium["myService"][msg._from]
                            os.system("screen -S {} -X quit".format(str(user)))
                            os.system('rm -rf {}'.format(str(user)))
                            time.sleep(2)
                            samudra.sendMention(msg.to, '「  Logout bypass  」\n> @! LogOut From Selfbot',' ', [msg._from])

                    elif text.lower() == "logout bypass" and msg._from not in premium['listLogin'] and to not in chatbot["botMute"]:
                        if msg._from in premium["myService"]:
                            samudra.sendMention(msg.to, '「  Logout bypass  」\nHai @!Sorry Please You Login First By Type < Login bypass > Or Type < Help Login >',' ', [msg._from])

                    elif text.lower() == "restart bypass" and to not in chatbot["botMute"]:
                        if msg._from in premium["myService"]:
                            user = premium["myService"][msg._from]
                            os.system("screen -S {} -X quit".format(str(user)))
                            os.system('screen -dmS {}'.format(user))
                            os.system('screen -r {} -X stuff "cd {} && python3 bypass.py \n"'.format(user, user))
                            time.sleep(3)
                            samudra.sendMention(msg.to, '「  Restart bypass  」\n> @! Succes Restart selfbot',' ', [msg._from])
#==========================================
                    elif text.lower() == "reboot":
                        if msg._from in myAdmin:
                            samudra.sendMention(to, "@! harap tunghu dulu bang samudra",' ', [msg._from])
                            restartBot()
                        else:pass

                    elif text.lower().startswith("logout ") and msg._from in myAdmin and to not in chatbot["botMute"]:
                        sep = text.split(" ")
                        anu = text.replace(sep[0] + " ","")
                        os.system("screen -S {} -X kill".format(str(anu)))
                        os.system('rm -rf {}'.format(str(anu)))
                        time.sleep(2)
                        samudra.sendMention(msg.to, '「 Remove 」\n> @!\nSucces remove file : {}'.format(str(anu)),' ', [msg._from])

                    elif text.lower() == "list user" and msg._from in myAdmin and to not in chatbot["botMute"]:
                        h = [a for a in premium['myService']]
                        k = len(h)//20
                        for aa in range(k+1):
                            msgas = '「 List Service 」\n'
                            no=0
                            for a in h:
                                no+=1
                                if premium['myService'][a] == "":cd = "None."
                                else:cd = premium['myService'][a]
                                if no == len(h):msgas+='\n{}. @!\nFile : {}'.format(no,cd)
                                else:msgas+='\n{}. @!\nFile : {}'.format(no,cd)
                            samudra.sendMention(msg.to, msgas,'', h)

                    elif text.lower().startswith("adduser ") and msg._from in myAdmin and to not in chatbot["botMute"]:
                            if 'MENTION' in msg.contentMetadata.keys()!= None:
                                key = eval(msg.contentMetadata["MENTION"])
                                key1 = key["MENTIONEES"][0]["M"]
                                if key1 not in premium['myService']:
                                    nama = str(text.split(' ')[1])
                                    premium['myService'][key1] =  '%s' % nama
                                    samudra.sendMention(msg.to, '「 Add Service  」\nAdded @! to service','', [key1])
                                else:
                                    samudra.sendMention(msg.to, '「 Add Service  」\nUser @! already in service','', [key1])

                    elif text.lower().startswith("deluser ") and msg._from in myAdmin and to not in chatbot["botMute"]:
                            if 'MENTION' in msg.contentMetadata.keys()!= None:
                                key = eval(msg.contentMetadata["MENTION"])
                                key1 = key["MENTIONEES"][0]["M"]
                                if key1 in premium['myService']:
                                    del premium['myService'][key1]
                                    samudra.sendMention(msg.to, '「 Del Service  」\nDeleted @! from service','', [key1])
                                else:
                                    samudra.sendMention(msg.to, '「 Del Service  」\n\nUser @! not in service','', [key1])

                    elif text.lower().startswith("addme ") and msg._from in myAdmin and to not in chatbot["botMute"]:
                        if msg._from not in premium['myService']:
                            nama = str(text.split(' ')[1])
                            premium['myService'][msg._from] =  '%s' % nama
                            samudra.sendMention(msg.to, "「 Add Me  」 \nAdd @! to Login..","",[msg._from])
                        else:
                            samudra.sendMention(msg.to, "「Add Me 」\nOwner @! already in List..","",[msg._from])

                    elif text.lower() == "help login" and to not in chatbot["botMute"]:
                        if msg._from in premium["myService"]:
                            samudra.sendMention(msg.to, 'Hai @!\n\n1. Type : Login template or login kikil\n2. Check Personal Chat\n3. Press the Link Qr\n4. Type Me To see your command',' ', [msg._from])

                    elif text.lower() == "myscreen":
                        if msg._from in myAdmin:
                            proses = os.popen("screen -list")
                            a = proses.read()
                            samudra.sendMessage(to, "{}\nSelf__Node V.01/2020".format(str(a)))
                            proses.close()

                    elif text.lower() == "myfilevps":
                        if msg._from in myAdmin:
                            proses = os.popen("ls")
                            a = proses.read()
                            samudra.sendMessage(to, "{}\nSelf__Node V.01/2020".format(str(a)))
                            proses.close()

                    elif text.lower().startswith("hapusfile ") and msg._from in myAdmin and to not in chatbot["botMute"]:
                        sep = text.split(" ")
                        anu = text.replace(sep[0] + " ","")
                        os.system('rm -rf {}'.format(str(anu)))
                        time.sleep(2)
                        samudra.sendMention(msg.to, '「 Remove 」\n> @!\nSucces remove file : {}'.format(str(anu)),' ', [msg._from])

                    elif text.lower().startswith("unzip ") and msg._from in myAdmin and to not in chatbot["botMute"]:
                        sep = text.split(" ")
                        anu = text.replace(sep[0] + " ","")
                        os.system('unzip {}'.format(str(anu)))
                        time.sleep(2)
                        samudra.sendMention(msg.to, '「 Remove 」\n> @!\nSucces unzip file : {}'.format(str(anu)),' ', [msg._from])
#========Helper_13lama======================================
                    elif cmd == "run bot1":
                        if msg._from in myAdmin:
                            os.system('screen -R 13lama -X kill')
                            os.system('cd 13lama && screen -S 13lama -dm python3 13bots.py')
                            samudra.sendMessage(msg.to, "Loading Run bot....")
                            time.sleep(2)
                            samudra.sendMessage(msg.to, "Succes!!! Bot siap digunakan")

                    elif cmd == "logout bot2":
                        if msg._from in myAdmin:
                            os.system('screen -R 13lama -X kill')
                            samudra.sendMessage(msg.to, "Bot diistirahatkan... \nSilahkan login jika diperlukan")
#========Helper_13baru======================================
                    elif cmd == "run purge":
                        if msg._from in myAdmin:
                            os.system('screen -R 13purge -X kill')
                            os.system('cd 13purge && screen -S 13purge -dm python3 13.py')
                            samudra.sendMessage(msg.to, "Loading Run bot....")
                            time.sleep(2)
                            samudra.sendMessage(msg.to, "Succes!!! Bot siap digunakan")

                    elif cmd == "logout purge":
                        if msg._from in myAdmin:
                            os.system('screen -R 13purge -X kill')
                            samudra.sendMessage(msg.to, "Bot diistirahatkan... \nSilahkan login jika diperlukan")
#===========================================================
                    if "/ti/g/" in msg.text.lower():
                        if settings["autoJoin"] == True or settings["autoJoin"] == False:
                            link_re = re.compile('(?:line\:\/|line\.me\/R)\/ti\/g\/([a-zA-Z0-9_-]+)?')
                            links = link_re.findall(text)
                            n_links = []
                            for l in links:
                                if l not in n_links:
                                   n_links.append(l)
                            for ticket_id in n_links:
                                group = samudra.findGroupByTicket(ticket_id)
                                samudra.acceptGroupInvitationByTicket(group.id,ticket_id)
        if op.type == 55:
            print("[ 55 ] NOTIFIED READ MESSAGE")
            try:
                if op.param1 in wait['readPoint']:
                    if op.param2 in wait['ROM1'][op.param1]:
                        wait['setTime'][op.param1][op.param2] = op.createdTime
                    else:
                        wait['ROM1'][op.param1][op.param2] = op.param2
                        wait['setTime'][op.param1][op.param2] = op.createdTime
                        try:
                            if wait['lurkauto'] == True:
                                if len(wait['setTime'][op.param1]) % 5 == 0:
                                    anulurk(op.param1,wait)
                        except:pass
                elif op.param2 in wait['readPoints']:
                    wait['lurkt'][op.param1][op.param2][op.param3] = op.createdTime
                    wait['lurkp'][op.param1][op.param2][op.param3] = op.param2
                else:pass
            except:
                pass
        backupData()
    except Exception as error:
        logError(error)
        traceback.print_tb(error.__traceback__)

def run():
    while True:
        try:
            ops = khiePoll.singleTrace(count=50)
            if ops != None:
                for op in ops:
                   loop.run_until_complete(khieBot(op))
                   #clientBot(op)
                   khiePoll.setRevision(op.revision)
        except Exception as e:
            logError(e)

if __name__ == "__main__":
    run()
